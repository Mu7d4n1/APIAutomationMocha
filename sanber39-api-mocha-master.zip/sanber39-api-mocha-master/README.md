# apiAutomationLive01

Installation

- npm install
- npm install supertest
- npm install mocha
- npm install chai

How to run

- npx mocha api/test/{file name}.js
