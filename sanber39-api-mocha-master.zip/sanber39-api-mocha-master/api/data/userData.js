
module.exports = { USER_DATA : {
    name : "sanber",
    job : "sqa"}  
}
  // or
